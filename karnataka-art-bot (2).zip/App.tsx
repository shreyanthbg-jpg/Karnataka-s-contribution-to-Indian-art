
import React, { useState } from 'react';
import Header from './components/Header';
import ChatWindow from './components/ChatWindow';
import InputBar from './components/InputBar';
import WelcomeScreen from './components/WelcomeScreen';
import { ChatMessage, ChatRole } from './types';
import * as geminiService from './services/geminiService';
import { playAudio } from './utils/audioUtils';

// Helper to convert file to base64
const fileToBase64 = (file: File): Promise<{ data: string, mimeType: string }> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
        const result = reader.result as string;
        const base64Data = result.split(',')[1];
        resolve({ data: base64Data, mimeType: file.type });
    };
    reader.onerror = error => reject(error);
  });
};


function App() {
  const [isChatVisible, setIsChatVisible] = useState(false);
  const [language, setLanguage] = useState<'en' | 'kn'>('en');
  const [isTranslating, setIsTranslating] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'init',
      role: ChatRole.BOT,
      text: "Hello! I am your guide to Karnataka's art. What would you like to learn about today?",
      image: "https://i.imgur.com/gJZ3y2q.jpeg",
    },
  ]);
  const [isLoading, setIsLoading] = useState(false);

  const handleLanguageToggle = async () => {
      const newLang = language === 'en' ? 'kn' : 'en';
      if (newLang === 'kn') {
          setIsTranslating(true);
          const messagesToTranslate = messages.filter(m => m.role === ChatRole.BOT && !m.kannadaText);
          
          const translationPromises = messagesToTranslate.map(async (msg) => {
              const translatedText = await geminiService.translateText(msg.text, 'Kannada');
              return { ...msg, kannadaText: translatedText };
          });

          const translatedMessages = await Promise.all(translationPromises);

          setMessages(prevMessages => {
              const updatedMessages = [...prevMessages];
              translatedMessages.forEach(translatedMsg => {
                  const index = updatedMessages.findIndex(m => m.id === translatedMsg.id);
                  if (index !== -1) {
                      updatedMessages[index] = translatedMsg;
                  }
              });
              return updatedMessages;
          });
          setIsTranslating(false);
      }
      setLanguage(newLang);
  };

  const handleSendMessage = async (prompt: string, file?: File, isThinkingMode?: boolean) => {
    setIsLoading(true);

    let userMessageText = prompt;
    let userMessage: ChatMessage = {
        id: Date.now().toString(),
        role: ChatRole.USER,
        text: prompt,
    };
    
    // Translate user prompt to English if in Kannada mode
    if (language === 'kn' && prompt) {
        const translatedPrompt = await geminiService.translateText(prompt, 'English');
        userMessage.text = translatedPrompt; // Store English version
        userMessage.kannadaText = prompt; // Store original Kannada
        userMessageText = translatedPrompt; // Use English for API
    }


    if (file) {
      try {
        const { data: base64Data, mimeType } = await fileToBase64(file);
        userMessage.image = `data:${mimeType};base64,${base64Data}`;
        
        const fullPrompt = `Analyze this image and tell me what Karnataka art form it represents. If it is not a Karnataka art form, please say so. If the user has also asked a question, answer it based on the image: "${userMessageText}"`;

        setMessages((prev) => [...prev, userMessage]);
        const response = await geminiService.analyzeImage(fullPrompt, base64Data, mimeType);
        addBotResponse(response.text);
      } catch (error) {
        console.error("Error processing file:", error);
        addBotResponse("Sorry, I had trouble analyzing that image.");
      }
    } else {
      setMessages((prev) => [...prev, userMessage]);
      try {
        const response = isThinkingMode 
            ? await geminiService.getComplexResponse(userMessageText) 
            : await geminiService.getChatResponse(userMessageText);
        addBotResponse(response.text);
      } catch (error) {
          console.error("Error fetching response:", error);
          addBotResponse("Sorry, something went wrong. Please try again.");
      }
    }
  };
  
  const addBotResponse = async (englishText: string) => {
      let newBotMessage: ChatMessage = {
          id: Date.now().toString(),
          role: ChatRole.BOT,
          text: englishText,
      };

      if (language === 'kn') {
          const kannadaText = await geminiService.translateText(englishText, 'Kannada');
          newBotMessage.kannadaText = kannadaText;
      }
      
      setMessages((prev) => [...prev, newBotMessage]);
      setIsLoading(false);
  };
  
  const handlePlayTTS = async (text: string) => {
      try {
          const audioData = await geminiService.getTextToSpeech(text);
          if (audioData) {
              await playAudio(audioData);
          }
      } catch (error) {
          console.error("TTS Error:", error);
          alert("Sorry, text-to-speech is currently unavailable.");
      }
  };

  if (!isChatVisible) {
      return <WelcomeScreen onEnterChat={() => setIsChatVisible(true)} />;
  }

  return (
    <div className="flex flex-col h-screen font-sans">
      <Header language={language} onLanguageToggle={handleLanguageToggle} isTranslating={isTranslating} />
      <ChatWindow
        messages={messages}
        isLoading={isLoading}
        language={language}
        onPlayTTS={handlePlayTTS}
        onSelectTopic={handleSendMessage}
      />
      <InputBar onSendMessage={handleSendMessage} isLoading={isLoading} language={language} />
    </div>
  );
}

export default App;
