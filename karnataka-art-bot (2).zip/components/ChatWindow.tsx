
import React, { useEffect, useRef } from 'react';
import { ChatMessage } from '../types';
import Message from './Message';
import TopicSelector from './TopicSelector';

interface ChatWindowProps {
  messages: ChatMessage[];
  isLoading: boolean;
  language: 'en' | 'kn';
  onPlayTTS: (text: string) => Promise<void>;
  onSelectTopic: (topic: string) => void;
}

const ChatWindow: React.FC<ChatWindowProps> = ({ messages, isLoading, language, onPlayTTS, onSelectTopic }) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  return (
    <div className="flex-1 overflow-y-auto p-4 md:px-6">
      <div className="max-w-3xl mx-auto">
        {messages.map((msg) => (
          <Message key={msg.id} message={msg} language={language} onPlayTTS={onPlayTTS} />
        ))}
        {messages.length <= 1 && (
            <TopicSelector onSelectTopic={onSelectTopic} />
        )}
        {isLoading && (
          <div className="flex items-start gap-3 my-4">
             <div className="w-8 h-8 text-orange-500 flex-shrink-0 mt-2">
               <i className="fas fa-robot"></i>
             </div>
             <div className="max-w-md lg:max-w-lg p-4 rounded-2xl shadow bg-white text-stone-800 rounded-tl-none">
               <div className="flex items-center space-x-2">
                 <div className="w-2 h-2 bg-orange-400 rounded-full animate-pulse delay-75"></div>
                 <div className="w-2 h-2 bg-orange-400 rounded-full animate-pulse delay-150"></div>
                 <div className="w-2 h-2 bg-orange-400 rounded-full animate-pulse delay-300"></div>
               </div>
             </div>
          </div>
        )}
        <div ref={scrollRef} />
      </div>
    </div>
  );
};

export default ChatWindow;
