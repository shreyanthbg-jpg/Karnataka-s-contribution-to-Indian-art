
import React, { useState, useRef } from 'react';
import { SendIcon, PaperclipIcon, BrainIcon } from './icons';

interface InputBarProps {
  onSendMessage: (prompt: string, file?: File, isThinking?: boolean) => void;
  isLoading: boolean;
  language: 'en' | 'kn';
}

const InputBar: React.FC<InputBarProps> = ({ onSendMessage, isLoading, language }) => {
  const [prompt, setPrompt] = useState('');
  const [isThinkingMode, setIsThinkingMode] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0];
    if (selectedFile) {
      setFile(selectedFile);
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreview(reader.result as string);
      };
      reader.readAsDataURL(selectedFile);
    }
  };

  const clearAttachment = () => {
      setFile(null);
      setPreview(null);
      if(fileInputRef.current) {
          fileInputRef.current.value = "";
      }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isLoading || (!prompt.trim() && !file)) return;
    
    onSendMessage(prompt, file || undefined, isThinkingMode);
    
    setPrompt('');
    clearAttachment();
  };
  
  const placeholderText = language === 'en' ? "Ask about Karnataka's art..." : "ಕರ್ನಾಟಕದ ಕಲೆಗಳ ಬಗ್ಗೆ ಕೇಳಿ...";
  const thinkingModeText = language === 'en' ? "Thinking Mode is active for complex questions." : "ಸಂಕೀರ್ಣ ಪ್ರಶ್ನೆಗಳಿಗೆ ಥಿಂಕಿಂಗ್ ಮೋಡ್ ಸಕ್ರಿಯವಾಗಿದೆ.";

  return (
    <div className="bg-white/80 backdrop-blur-sm border-t border-stone-200 sticky bottom-0">
      <div className="max-w-3xl mx-auto p-4">
        {preview && (
          <div className="relative w-24 h-24 mb-2 rounded-lg overflow-hidden border">
            <img src={preview} alt="upload preview" className="w-full h-full object-cover" />
            <button onClick={clearAttachment} className="absolute top-1 right-1 bg-black/50 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm">&times;</button>
          </div>
        )}
        <form onSubmit={handleSubmit} className="flex items-center gap-2 bg-stone-100 border border-stone-300 rounded-full p-1 shadow-inner">
          <button
            type="button"
            title="Attach Image"
            onClick={() => fileInputRef.current?.click()}
            className="p-2 text-stone-500 hover:text-orange-600 rounded-full transition-colors"
          >
            <PaperclipIcon className="w-6 h-6" />
          </button>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            className="hidden"
            accept="image/*"
          />
          <input
            type="text"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder={placeholderText}
            className="flex-1 bg-transparent focus:outline-none px-2 text-stone-800 placeholder-stone-400"
            disabled={isLoading}
          />
           <button
            type="button"
            title={isThinkingMode ? "Disable Thinking Mode (Gemini 2.5 Pro)" : "Enable Thinking Mode (Gemini 2.5 Pro)"}
            onClick={() => setIsThinkingMode(!isThinkingMode)}
            className={`p-2 rounded-full transition-colors ${
              isThinkingMode ? 'text-orange-500 bg-orange-100' : 'text-stone-500 hover:text-orange-600'
            }`}
          >
            <BrainIcon className="w-6 h-6" />
          </button>
          <button
            type="submit"
            disabled={isLoading || (!prompt.trim() && !file)}
            className="p-2 rounded-full bg-orange-500 text-white hover:bg-orange-600 disabled:bg-stone-300 disabled:cursor-not-allowed transition-colors"
          >
            <SendIcon className="w-6 h-6" />
          </button>
        </form>
        <p className={`text-xs text-center mt-2 transition-opacity duration-300 ${isThinkingMode ? 'opacity-100 text-orange-600' : 'opacity-0'}`}>
          {thinkingModeText}
        </p>
      </div>
    </div>
  );
};

export default InputBar;
