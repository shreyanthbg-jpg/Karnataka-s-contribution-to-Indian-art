
import React, { useState } from 'react';
import { ChatMessage, ChatRole } from '../types';
import { BotIcon, SpeakerIcon } from './icons';

interface MessageProps {
  message: ChatMessage;
  language: 'en' | 'kn';
  onPlayTTS: (text: string) => Promise<void>;
}

const Message: React.FC<MessageProps> = ({ message, language, onPlayTTS }) => {
  const { role, text, kannadaText, image } = message;
  const isBot = role === ChatRole.BOT;
  const [isSpeaking, setIsSpeaking] = useState(false);

  const textToDisplay = (language === 'kn' && kannadaText) ? kannadaText : text;

  const handlePlayAudio = async () => {
      if (isSpeaking || !textToDisplay) return;
      setIsSpeaking(true);
      await onPlayTTS(textToDisplay);
      setIsSpeaking(false);
  };

  const containerClasses = `flex items-start gap-3 my-4 ${isBot ? '' : 'flex-row-reverse'}`;
  const bubbleClasses = `max-w-md lg:max-w-lg p-4 rounded-2xl shadow ${
    isBot 
      ? 'bg-white text-stone-800 rounded-tl-none' 
      : 'bg-orange-500 text-white rounded-tr-none'
  }`;

  return (
    <div className={containerClasses}>
      {isBot && <BotIcon className="w-8 h-8 text-orange-500 flex-shrink-0 mt-2" />}
      <div className="flex flex-col">
        <div className={bubbleClasses}>
            {image && (
                <img src={image} alt="User upload" className="rounded-lg mb-2 max-h-60 w-auto" />
            )}
            <p className="whitespace-pre-wrap">{textToDisplay}</p>
        </div>
        {isBot && textToDisplay && (
            <button 
                onClick={handlePlayAudio} 
                className={`flex items-center gap-1 text-sm text-stone-500 hover:text-orange-600 transition-colors mt-1 px-2 py-1 rounded-full ${isBot ? '' : 'self-end'}`}
                disabled={isSpeaking}
            >
                <SpeakerIcon className={`w-4 h-4 ${isSpeaking ? 'animate-pulse text-orange-600' : ''}`} />
                {isSpeaking ? (language === 'kn' ? 'ಮಾತನಾಡುತ್ತಿದೆ...' : 'Speaking...') : (language === 'kn' ? 'ಕೇಳಿ' : 'Listen')}
            </button>
        )}
      </div>
    </div>
  );
};

export default Message;
