
import React from 'react';

const topics = ["Painting", "Music", "Dance", "Crafts"];

interface TopicSelectorProps {
  onSelectTopic: (topic: string) => void;
}

const TopicSelector: React.FC<TopicSelectorProps> = ({ onSelectTopic }) => {
  return (
    <div className="p-4 flex flex-wrap justify-center gap-3">
      {topics.map((topic) => (
        <button
          key={topic}
          onClick={() => onSelectTopic(`Tell me about Karnataka's ${topic}.`)}
          className="px-4 py-2 bg-white border border-orange-300 text-orange-600 font-semibold rounded-full hover:bg-orange-500 hover:text-white hover:shadow-lg transform hover:-translate-y-0.5 transition-all duration-200"
        >
          {topic}
        </button>
      ))}
    </div>
  );
};

export default TopicSelector;
