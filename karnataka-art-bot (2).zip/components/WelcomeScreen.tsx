import React from 'react';

interface WelcomeScreenProps {
  onEnterChat: () => void;
}

const WelcomeScreen: React.FC<WelcomeScreenProps> = ({ onEnterChat }) => {
  return (
    <div
      className="h-screen w-screen bg-cover bg-center flex flex-col items-center justify-center text-white"
      style={{ backgroundImage: "url('https://karnatakatourism.org/wp-content/uploads/2020/05/Yakshagana-2.jpg')" }}
    >
      <div className="absolute inset-0 bg-black/60"></div>
      <div className="relative z-10 text-center p-8 max-w-2xl">
        <h1 className="text-4xl md:text-6xl font-extrabold mb-4 tracking-tight" style={{ textShadow: '2px 2px 4px rgba(0,0,0,0.7)' }}>
          Karnataka Art Bot
        </h1>
        <p className="text-lg md:text-xl mb-8 font-light" style={{ textShadow: '1px 1px 2px rgba(0,0,0,0.7)' }}>
          Discover the rich tapestry of Karnataka's artistic heritage. From ancient temples to vibrant paintings, your journey begins here.
        </p>
        <button
          onClick={onEnterChat}
          className="bg-orange-500 text-white font-extrabold py-4 px-10 rounded-full text-xl hover:bg-orange-600 transform hover:scale-105 transition-all duration-300 ease-in-out shadow-lg hover:shadow-2xl focus:outline-none focus:ring-4 focus:ring-orange-300"
        >
          Enter the Chat
        </button>
      </div>
    </div>
  );
};

export default WelcomeScreen;
