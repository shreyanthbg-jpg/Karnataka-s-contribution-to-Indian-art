
import { GoogleGenAI, Modality, GenerateContentResponse } from "@google/genai";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const systemInstruction = "You are a friendly and knowledgeable guide to Karnataka's art forms. You are talking to a student. Your answers must be short, simple, and engaging, typically 2-4 sentences. Do not use complex vocabulary. When asked about a topic, give a concise explanation. The topics are Mysore paintings, Hoysala temples, Carnatic music, Yakshagana dance, and sandalwood carvings.";

export const getChatResponse = async (prompt: string): Promise<GenerateContentResponse> => {
    return await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: [{ parts: [{ text: prompt }] }],
        config: {
            systemInstruction: systemInstruction,
        },
    });
};

export const getComplexResponse = async (prompt: string): Promise<GenerateContentResponse> => {
    return await ai.models.generateContent({
        model: 'gemini-2.5-pro',
        contents: [{ parts: [{ text: prompt }] }],
        config: {
            systemInstruction: systemInstruction,
            thinkingConfig: { thinkingBudget: 32768 },
        },
    });
};

export const analyzeImage = async (prompt: string, imageBase64: string, mimeType: string): Promise<GenerateContentResponse> => {
    return await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: {
            parts: [
                { text: prompt },
                {
                    inlineData: {
                        data: imageBase64,
                        mimeType: mimeType,
                    },
                },
            ],
        },
    });
};

export const getTextToSpeech = async (text: string): Promise<string | null> => {
    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        contents: [{ parts: [{ text: `Say it clearly and warmly: ${text}` }] }],
        config: {
            responseModalities: [Modality.AUDIO],
            speechConfig: {
                voiceConfig: {
                    prebuiltVoiceConfig: { voiceName: 'Kore' },
                },
            },
        },
    });
    
    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    return base64Audio || null;
};

export const translateText = async (text: string, targetLang: 'Kannada' | 'English'): Promise<string> => {
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: [{ parts: [{ text: `Translate the following text to ${targetLang}: "${text}"` }] }],
             config: {
                // Ensure the translation is concise and accurate
                temperature: 0.2,
            },
        });
        return response.text.trim();
    } catch (error) {
        console.error("Translation failed:", error);
        return text; // Fallback to original text on error
    }
};
