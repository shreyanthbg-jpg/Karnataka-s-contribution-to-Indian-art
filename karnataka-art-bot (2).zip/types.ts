
export enum ChatRole {
  USER = 'user',
  BOT = 'bot',
}

export interface ChatMessage {
  id: string;
  role: ChatRole;
  text: string; // Always stores the English version
  kannadaText?: string; // Stores the Kannada translation
  image?: string; // base64 data URL for display
}
